## Pypi-quicksort

This is python implementation of quick sort algorithm that's installable through pip package manager
